Steel Battalion:LoC Insignia Tool v.2

This is the second version of the the tool and now thanks to Team X4 we are able to
resign the insignias to work flawlessly.

How to use:

Use insignia tool to create the image, and XSavSig to resign it.

This is a special XSaveSig collection and will ONLY resign Insignia files.

Most of the image functions such as resize, color reduce are rather primitive.
The functions are only included for people who may not have an image editor,
if you don't get one and until then you can use the built in functions.

File menu functions:
 Open: Opens a file...
 Close: You guessed it, closes the open file...
 Save:
  Submenu Save Image: Save the image as the selected format
  Submenu Make Insignia: Phrase the image, and write it to file
 Exit: Exits

Edit menu functions:
 Resize: Make the current image 64x64, careful of images without the same length
	and width they may resize to weird looking proportions.
 Colors:
  Submenu Count: Counts the current color within the image, if more than 1000+ colors
		found it just displays 1000+.  Insignias must be 16 colors, more like 15
		and one transparent color.  Just be careful that your transparent color
		isn't something you want to be transparent.
  Submenu Reduct: Reduces the colors down to 16 unique colors, so images with a lot of
		colors to start with will probably not look so great.  The algorithm used
		is a good deal better than a nearest color, but still leaves a lot to be
		desired. Photoshop has a nice perspective local algorithm that will make
		some nice quality insignias.
 Box Image: This is a simple cropping tool that will make the image exactly the same
		same length and width.  I plan on improving this in the future it is
		still buggy.  To use just select Box Image from the menu, then click
		on the topleft desired spot and hold the button down.  Drag the box
		to the bottomRight desired spot and release the left mouse button.
		Do not how ever drag any where off the canvas or you'll get white space.
		Again, I plan to fix this soon.

Zoom menu functions:
 three choices, 64x64, 128x128, 192x192
 these will allow you change the VIEW of the canvas

Plans for the future (no particular Order):
 Better Cropping function
 Intermix the XsavSig DLL to support signing within the tool
 Any other suggestions will be considered
 Perhaps a better Color Quantization Algorithm
 Maybe something REALLY big, still in research on this one though, so hush hush

Thanks & Credit
 TeamX4, you are Jesus - XsavSig, Custom Libraries, etc...